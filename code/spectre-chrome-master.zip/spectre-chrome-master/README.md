# Minimal Spectre JS PoC for Chrome

  
```
## Chrome JavaScript version

Enable `#shared-array-buffer` in `chrome:///flags` under your own risk...

Modified to fix Chrome Worker origin policy POC from: github.com/cgvwzq/spectre

Tested on Chrome Version 62.0.3202.94
![alt-tag](https://raw.githubusercontent.com/ascendr/spectre-chrome/master/spectreChrome.JPG)
